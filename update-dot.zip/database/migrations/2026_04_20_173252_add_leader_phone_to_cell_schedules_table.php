<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
{
    Schema::table('cell_schedules', function (Blueprint $table) {
        $table->string('leader_phone')->nullable()->after('location'); // Menambahkan kolom nomor telp
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('cell_schedules', function (Blueprint $table) {
            //
        });
    }
};
